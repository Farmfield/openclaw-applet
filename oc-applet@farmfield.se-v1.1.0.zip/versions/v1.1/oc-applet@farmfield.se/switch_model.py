#!/usr/bin/env python3
"""
Switch Model Helper for OC-Applet v1.1
Uses OpenClaw TUI to inject /model command into active session.
"""
import subprocess
import sys
import os

# Full paths (Cinnamon has limited PATH)
TIMEOUT_BIN = "/usr/bin/timeout"
OPENCLAW_BIN = os.path.expanduser('~/.npm-global/bin/openclaw')
LOG_FILE = '/tmp/model_switch_log.txt'

def log_output(message):
    """Appends a message to the log file."""
    try:
        with open(LOG_FILE, 'a') as f:
            f.write(message + "\n")
    except Exception as e:
        print(f"Log error: {e}", file=sys.stderr)

def switch_model(session_key, target_model):
    """Switches model using TUI message injection."""
    log_output(f"--- TUI Switch: {session_key} to {target_model} ---")
    try:
        # Use timeout + tui with --message to inject /model command
        # Redirect all I/O to /dev/null to run headless
        command = f"{TIMEOUT_BIN} 5 {OPENCLAW_BIN} tui --session {session_key} --message '/model {target_model}' </dev/null >/dev/null 2>&1"
        log_output(f"Executing: {command}")

        # Use shell=True to handle redirects properly
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=10
        )

        log_output(f"Return Code: {result.returncode}")
        # 124 = timeout killed it (expected/success), 0 = normal exit
        if result.returncode in (0, 124):
            log_output("Success: TUI command executed")
            return True
        else:
            log_output(f"Error: exit code {result.returncode}")
            if result.stderr:
                log_output(f"Stderr: {result.stderr[:200]}")
            return False

    except subprocess.TimeoutExpired:
        log_output("Error: Command timed out (10s)")
        return False
    except Exception as e:
        log_output(f"Error: {e}")
        return False

if __name__ == "__main__":
    if len(sys.argv) < 3:
        log_output("Usage: switch_model.py <session-key> <model-id>")
        sys.exit(1)

    session_key = sys.argv[1]
    target_model = sys.argv[2]

    if switch_model(session_key, target_model):
        sys.exit(0)
    else:
        sys.exit(1)
