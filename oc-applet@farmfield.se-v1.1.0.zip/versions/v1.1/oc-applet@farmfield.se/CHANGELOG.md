# OC-Applet Changelog

## v1.1 - "Works kinda better"

### Features
- Highly customizable menu via `menu.json` — enable/disable items, change labels, add custom commands
- Models submenu grouped by provider with clean display names
- Smart model switching via Python helper with Gateway API
- Fixed width menu to prevent layout recalculation shiver

### Fixes
- Kimi checkbox independence via exact matching in model detection
- Gemini 3 → 3.1 Pro Preview paths updated

### Notes
- TUI hack: menu uses fixed width (230px) to prevent Cinnamon flickering during open/close

---

## v1.0 - "Mostly worked"

- Initial release
- Basic menu with Start/Stop/Restart/Dashboard actions
- Model switching support

---

*Email johnny@farmfield.se for requests/bugs*
